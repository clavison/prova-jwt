package br.senai.prova_jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProvaJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvaJwtApplication.class, args);
	}

}
